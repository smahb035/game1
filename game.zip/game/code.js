var canvas = document.getElementById("Canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// function resize
window.addEventListener('resize', canvasResize, false);
function canvasResize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

var context = canvas.getContext("2d");


/////////       1        //////////


// ingame variable
var score = 0;
var lives = 3;

/////////       2        //////////

// ball information
var speedBall = 4;
var x = canvas.width/2;
var y = canvas.height-32;
var dx = speedBall;
var dy = -speedBall;
var ballRadius = 8;

/////////       3        //////////

// paddle information
var paddleHeight = 15;
var paddleWidth = 148;
var paddleX = (canvas.width-paddleWidth)/2;

// button information
var leftPress = false;
var rightPress = false;


/////////       4        //////////

// bricks information
var brickRowCount = 3;
var brickColumnCount = 3;
var brickWidth = canvas.width/(brickColumnCount+1);
var brickHeight = 20;
var brickPadding = 10;
var brickOffsetTop = 16;
var brickOffsetLeft = brickWidth/2;
var brickX = 0;
var brickY = 0;

var bricks = [];
for(var r = 0; r<brickRowCount; r++) {
    bricks[r] = [];
    for(var c = 0; c<brickColumnCount; c++) {
        bricks[r][c] = { x:0 , y:0 , ada : true };
    }
}


/////////       5        //////////

// handle button
document.addEventListener("keydown", keyDownHandler , false);
document.addEventListener("keyup", keyUpHandler , false);


/////////       6        //////////

function drawBall() {
    // ball image
    context.beginPath();
    context.arc(x,y,ballRadius,0,Math.PI*2);
    context.fillStyle = "gold";
    context.fill();
    context.closePath();
}


/////////       7        //////////

function drawPaddle() {
    // paddle image
    context.beginPath();
    context.rect(paddleX,canvas.height-paddleHeight,paddleWidth,paddleHeight);
    context.fillStyle = "#C02942"
    context.fill();
    context.closePath();
}


/////////       8        //////////

function drawBricks() {
    // bricks image
    for(var r = 0; r<brickRowCount; r++) {
        for(var c = 0; c<brickColumnCount; c++) {
            if( bricks[r][c].ada ) {
                brickX = (c*(brickWidth+brickPadding)) + brickOffsetLeft;
                brickY = (r*(brickHeight+brickPadding)) + brickOffsetTop;

                bricks[r][c].x = brickX;
                bricks[r][c].y = brickY;

                context.beginPath();
                context.rect(brickX,brickY,brickWidth,brickHeight);
                context.fillStyle = "#542437";
                context.fill();
                context.closePath();
            }
        }
    }
}


/////////       9        //////////

function drawScore() {
    context.font = "16px Haettenschweiler";
    context.fillStyle = "#ECD078";
    context.fillText("Score: "+score, 8, 20);
}


/////////       10        //////////

function drawLives() {
    context.font = "16px Haettenschweiler";
    context.fillStyle = "#ECD078";
    context.fillText("Lives: " + lives, canvas.width-65, 20);
}


/////////       11        //////////

function checkHit() {
    // When the ball hits the bricks
    for(var c = 0; c<brickColumnCount; c++) {
        for(var r = 0; r<brickRowCount; r++) {
            var brick = bricks[r][c];
            if( brick.ada ) {
                if(brick.x < x && brick.x+brickWidth > x && brick.y+brickHeight > y && brick.y  < y) {
                    dy = -dy;
                    bricks[r][c].ada = false;
                    score++;

                    if(score == brickRowCount * brickColumnCount ) {
                        alert("Congratulations! You've won!");
                        document.location.reload();         // reload
                    }
                }
            }
        }
    }
}



/////////       12        //////////

function keyDownHandler(k) {
    if(k.key == "Right" || k.key == "ArrowRight") {
        rightPress = true;
    }
    else if(k.key == "Left" || k.key == "ArrowLeft") {
        leftPress = true;
    }
}

function keyUpHandler(k) {
    if(k.key == "Right" || k.key == "ArrowRight") {
        rightPress = false;
    }
    else if(k.key == "Left" || k.key == "ArrowLeft") {
        leftPress = false;
    }
}



/////////       13        //////////

function draw() {
    // reset canvas
    context.clearRect(0,0,canvas.width,canvas.height);

    drawScore();
    drawBall();
    drawPaddle();
    drawBricks();
    drawLives();
    checkHit();


    /////////       14        //////////

    // During a collision with a wall
    if( x + dx < ballRadius || x + dx > canvas.width - ballRadius) {
        dx = -dx;
    }
    if( y + dy < ballRadius ) {
        dy = -dy;
    }
    else if( y + dy > canvas.height - ballRadius) {
        if( paddleX < x && paddleX + paddleWidth > x) {
            dy = -dy;
        }
        else {
            lives--;

            if(!lives) {
                alert("Lives are finished. You didn't win!!!");
                document.location.reload(); // reload
            } else {
                speedBall = 4;
                x = canvas.width/2;
                y = canvas.height-32;
                dx = speedBall;
                dy = -speedBall;
                paddleX = (canvas.width-paddleWidth)/2;
            }
        }
    }


    /////////       15        //////////

    // button
    if(rightPress && paddleX < canvas.width-paddleWidth) {
        paddleX += 8;
    }
    else if (leftPress && paddleX > 0) {
        paddleX -= 8;
    }

    // ball movement
    x += dx;
    y += dy;
    //console.log("("+x+","+y+")");

    // call draw again
    requestAnimationFrame(draw);
}
draw();



/////////       16        //////////
